/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyecto2_lfa;

/**
 *
 * @author zaneb
 */

  import java.io.*;

public class Proyecto2_LFA {

    public static void main(String[] args) {

        String archivoEntrada = "entrada.txt";
        String archivoTokens = "tokens.txt";
        String archivoErrores = "errores.txt";

        try {
            BufferedReader lector = new BufferedReader(new FileReader(archivoEntrada)); 
            BufferedWriter tokens = new BufferedWriter(new FileWriter(archivoTokens));
            BufferedWriter errores = new BufferedWriter(new FileWriter(archivoErrores));

            String linea;
            int numLinea = 1;

            while ((linea = lector.readLine()) != null) {
                linea = linea.trim();
                boolean encontrado = false;

                
                if (linea.startsWith("<Operacion=")) {
                    if (linea.contains("SUMA") || linea.contains("RESTA") || linea.contains("MULTIPLICACION") ||
                        linea.contains("DIVISION") || linea.contains("POTENCIA") || linea.contains("RAIZ") ||
                        linea.contains("INVERSO") || linea.contains("MOD")) {
                        tokens.write("Linea " + numLinea + " -> TOKEN: OPE_A -> " + linea + "\n");
                    } else {
                        errores.write("Error lexico en linea " + numLinea + ": Operacion no valida -> " + linea + "\n");
                    }
                    encontrado = true;
                }

                
                else if (linea.equals("</Operacion>")) {
                    tokens.write("Linea " + numLinea + " -> TOKEN: OPE_C -> " + linea + "\n");
                    encontrado = true;
                }

                
                else if (linea.startsWith("<Numero>") && linea.endsWith("</Numero>")) {
                 
                    String contenido = linea.replace("<Numero>", "").replace("</Numero>", "").trim();

                    
                    if (esNumero(contenido)) {
                        tokens.write("Linea " + numLinea + " -> TOKEN: NUM -> " + contenido + "\n");
                    } else {
                        errores.write("Error lexico en linea " + numLinea + ": Valor no numerico -> " + linea + "\n");
                    }
                    encontrado = true;
                }

               
                else if (linea.startsWith("<P>") && linea.endsWith("</P>")) {
                    String contenido = linea.replace("<P>", "").replace("</P>", "").trim();
                    if (esNumero(contenido)) {
                        tokens.write("Linea " + numLinea + " -> TOKEN: NUM_P -> " + contenido + "\n");
                    } else {
                        errores.write("Error lexico en linea " + numLinea + ": Valor P invalido -> " + linea + "\n");
                    }
                    encontrado = true;
                }

                else if (linea.startsWith("<R>") && linea.endsWith("</R>")) {
                    String contenido = linea.replace("<R>", "").replace("</R>", "").trim();
                    if (esNumero(contenido)) {
                        tokens.write("Linea " + numLinea + " -> TOKEN: NUM_R -> " + contenido + "\n");
                    } else {
                        errores.write("Error lexico en linea " + numLinea + ": Valor R invalido -> " + linea + "\n");
                    }
                    encontrado = true;
                }

                // Falta agregar el reconocimiento de errores más específicos,
                // o detectar si el orden de etiquetas es incorrecto.
                // También se podría agregar verificación del orden correcto
                // de apertura y cierre de las operaciones.

                if (!encontrado && !linea.isEmpty()) {
                    errores.write("Error lexico en linea " + numLinea + ": " + linea + "\n");
                }

                numLinea++;
            }

            lector.close();
            tokens.close();
            errores.close();

            System.out.println("Analisis terminado. Revisa los archivos de salida.");

        } catch (IOException e) {
            System.out.println("Error al leer o escribir los archivos.");
        }
    }

  
    public static boolean esNumero(String texto) {
        try {
            Double.parseDouble(texto);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}


